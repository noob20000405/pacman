/**
 * \file fantomes.h
 * \brief bibliotehque de fantomes.c
 */
#ifndef FANTOMES_H
#define FANTOMES_H
#define P_SIZE 10
#define NB_F 3

/**
 * \struct fantome
 * \typedef fantome_t
 * \brief struct d'une fantome(x, y : la position).
 */
struct fantome
{
  int x;
  int y;
};

typedef struct fantome fantome_t;

/**
 * \brief Créer les fantomes dans les positions aléatoires.
 * \param pl le plateau; n nombre de fantomes.
 * \return Le tableau des fantomes.
 */
fantome_t** placer_n_f(int** pl, int n);

/**
 * \brief Déplacer aléatoirement chaque fantome.
 * \param pl le plateau; fants un tableau des fantomes.
 * \return Rien.
 */
void deplacer_f(int** pl, fantome_t** fants);

#endif
