/**
 * \file fantomes.c
 * \brief fantomes.c
 */
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"fantomes.h"
#include"../plateau/plateau.h"

fantome_t** placer_n_f(int** pl, int n)
{
  int x = -1;//coordonnée de chaque fantome.
  int y = -1;
  
  
  int i;
  srand(time(NULL));

  fantome_t** fantome = malloc(n*sizeof(fantome_t*));

  for(i=0;i<n;i++)
  {
    fantome[i] = malloc(sizeof(fantome_t));
  }
  
  
  for(i=0;i<n;i++)//mettre les fantomes dans les positions aléatoires.
  {
  	x = (rand() % ((P_SIZE-1)-1))+ 1;
  	y = (rand() % ((P_SIZE-1)-1))+ 1;
  	
  	while(!valide(pl, y, x))
	{
  	  x = (rand() % ((P_SIZE-1)-1))+ 1;
  	  y = (rand() % ((P_SIZE-1)-1))+ 1;

	}

	pl[y][x] = 3;
  	fantome[i]->x = x;
    	fantome[i]->y = y;

  }
  
  return fantome;
}

void deplacer_f(int** pl, fantome_t** fants)
{

  srand(time(NULL));
  int x, y;
  int i;
  int d = 0;//la direction de déplacement. 0, 1, 2, 3 quatre en total.


  
  for(i=0;i<NB_F;i++)
  {
  	d = rand() % 4;
  	x = fants[i]->x;
  	y = fants[i]->y;
  	
  	switch(d)
  	{
	    case 0://vers en haut.
	 	 	if(valide(pl, y-1, x))
		  	{
		
	  		  pl[y][x] = 0;
	  		  y--;
	  		  fants[i]->y = y;
	  		  pl[y][x] = 3;
	  	    }
	  	  break;
	    case 1://vers en bas.
	  		if(valide(pl, y+1, x))
			{
	  	 	 pl[y][x] = 0;
	  	 	 y++;
	  	 	 fants[i]->y = y;
	  	 	 pl[y][x] = 3;
			}
			break;
		case 2://vers à gauche.
			if(valide(pl, y, x-1))
			{
			  pl[y][x] = 0;
			  x--;
			  fants[i]->x = x;
			  pl[y][x] = 3;
			}
			break;
		case 3://vers à droite.
			if(valide(pl, y, x+1))
			{
				pl[y][x] = 0;
				x++;
				fants[i]->x = x;
				pl[y][x] = 3;
			}
			break;
	}
  }
}
