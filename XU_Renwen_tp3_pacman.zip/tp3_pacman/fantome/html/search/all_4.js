var searchData=
[
  ['p_5fsize',['P_SIZE',['../fantomes_8h.html#ae064cb82bfc5221dffdfb671be7c3004',1,'fantomes.h']]],
  ['placer_5fn_5ff',['placer_n_f',['../fantomes_8c.html#ab313becd7b67fd190c18c94f5372e7a4',1,'placer_n_f(int **pl, int n):&#160;fantomes.c'],['../fantomes_8h.html#ab313becd7b67fd190c18c94f5372e7a4',1,'placer_n_f(int **pl, int n):&#160;fantomes.c']]]
];
