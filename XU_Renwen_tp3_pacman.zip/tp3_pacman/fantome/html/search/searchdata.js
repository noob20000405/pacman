var indexSectionsWithContent =
{
  0: "dfmnpxy",
  1: "f",
  2: "f",
  3: "dmp",
  4: "xy",
  5: "f",
  6: "np"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

