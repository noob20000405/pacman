#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include <unistd.h> //sleep()
#include"fantomes.h"
#include"../plateau/plateau.h"
#include"../affichage/affichage.h"

int main()
{
	
	int** pl = creer_plateau();
	fantome_t** fants = placer_n_f(pl, 3);//test placer_n_f.
	afficher(pl);
	
	printf("1eme tour : \n");
	deplacer_f(pl, fants);//test deplacer_f.

	afficher(pl);
	
	sleep(1);
	
	printf("2eme tour : \n");
	deplacer_f(pl, fants);
	afficher(pl);
	
	return 0;
}
