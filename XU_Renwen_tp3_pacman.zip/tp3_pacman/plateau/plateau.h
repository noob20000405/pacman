/**
 * \file joueur.h
 * \brief bibliotheque de plateau.c
 */
#ifndef PLATEAU_H
#define PLATEAU_H
#define P_SIZE 10
#define NB_MUR 20

/**
 * \brief Crée un plateau.
 * \param Vide.
 * \return Le plateau.(un tableau d'entiers à deux dimension)
 */
int** creer_plateau();

/**
 * \brief Determiner si on peut deplacer vers une certaine case.
 * \param pl le plateau; i, j, les coordonnées d'un points dans ce plateau.
 * \return Un entier 0 ou 1.(non valide ou valide)
 */
int valide(int** pl, int i, int j);

#endif
