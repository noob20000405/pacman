var searchData=
[
  ['valide',['valide',['../plateau_8c.html#a0f8b7a6ede4a80496db6d51422e61138',1,'valide(int **pl, int i, int j):&#160;plateau.c'],['../plateau_8h.html#a0f8b7a6ede4a80496db6d51422e61138',1,'valide(int **pl, int i, int j):&#160;plateau.c']]]
];
