/**
 * \file plateau.c
 * \brief plateau.c
 */
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"plateau.h"


int** creer_plateau()
{
  int i, j;
  int cpt_mur = 0;
  int** pl = (int**)malloc(sizeof(int*)*P_SIZE);
  
  srand(time(NULL));
  
  for(i=0;i<P_SIZE;i++)
    {
      pl[i] = (int*)malloc(sizeof(int)*P_SIZE);
    }

  for(i=0;i<P_SIZE;i++)
    {
      for(j=0;j<P_SIZE;j++)
	{
	  if(i==0 || i==P_SIZE - 1)
	    {
	      pl[i][j] = 2;//mur en haut et en bas.
	    }
	  else if(j==0 || j==P_SIZE - 1)
	    {
	      pl[i][j] = 5;//mur à gauche et à droite.
	    }
	  else
	    {
	      pl[i][j] = 1;//les pacs.
	    }
	}
    }
    
    for(cpt_mur=0;cpt_mur<NB_MUR;cpt_mur++)//mur aléatoire. NB_MUR : nombre des murs aléatoires. Défini dans plateau.h.
    {
      i = (rand() % ((P_SIZE-1)-1))+1;
      j = (rand() % ((P_SIZE-1)-1))+1;
      
      pl[i][j] = 6;
    }

  return pl;
  
}

int valide(int** pl, int i, int j)
{

  if(pl[i][j] == 0 || pl[i][j] == 1 || pl[i][j] == 4)//vide ou pac ou joueur, c'est valide.
  {
    return 1;
  }

  return 0;
}
