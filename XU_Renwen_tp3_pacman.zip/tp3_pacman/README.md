# Auteurs
- XU Renwen
- ZHOU Zixun
# Commande de compilation
- gcc plateau/plateau.c affichage/affichage.c fantome/fantomes.c joueur/joueur.c main.c -o jeu
- ./jeu
# Commande dans ce jeu
## Choix de la position initiale
- Il faut une virgule et un espace entre les deux chiffres, ex :
1. 2, 3
2. 5, 5
## Déplacement
- s/d(gauche/droite), a/w(haut/bas)
## Quitter
- ctrl + c :-)
# Extension
- Améliorer l’affichage en ajoutant des couleurs et en rafraîchissant une fenêtre.
- L'extension est directement écrite dans les modules initiaux(module d'affichage et main.c). Sinon l'affichage pourrais être très moche.
# Merci pour votre correction !

