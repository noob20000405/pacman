/**
 * \file affichage.c
 * \brief affichage.c
 */
#include<stdio.h>
#include<stdlib.h>
#include"affichage.h"

void afficher_brut(int** pl)
{
  int i, j;
  for(i=0;i<P_SIZE;i++)
  {
    for(j=0;j<P_SIZE;j++)
    {
      printf("%d", pl[i][j]);
      if(j == P_SIZE - 1)
      {
      	printf("\n");
      }
    }
  }
}

void afficher(int** pl)
{
  int i, j;
  
  for(i=0;i<P_SIZE;i++)
  {
    for(j=0;j<P_SIZE;j++)
    {
      if(pl[i][j] == 1)//pac.
      {
        printf(". ");
      }
      if(pl[i][j] == 2)//mur en haut et en bas.
      {
        printf("--");
      }
      if(pl[i][j] == 3)//fantome.
      {
      	BLUE//changer la couleur. Défini dans affichage.h.
        printf("F ");
        CLOSE//initialiser la couleur. Défini dans affichage.h.
      }
      if(pl[i][j] == 4)//joueur.
      {
	YELLOW
        printf("J ");
        CLOSE
      }
      if(pl[i][j] == 0)//vide.
      {
        printf("  ");
      }
      if(pl[i][j] == 5)//mur à gauche et à droite.
      {
      	printf("| ");
      }
      if(pl[i][j] == 6)//mur aléatoire.
      {
      	printf("# ");
      }
      if(j == P_SIZE - 1)
      {
      	printf("\n");
      }
    }
  }
}
