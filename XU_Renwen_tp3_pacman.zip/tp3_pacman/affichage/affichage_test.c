#include<stdio.h>
#include<stdlib.h>
#include"affichage.h"
#include"../plateau/plateau.h"

int main()
{
  int** pl = creer_plateau();//test creer_plateau et afficher_brut et afficher.
  afficher_brut(pl);
  afficher(pl);
	
	return 0;
}
