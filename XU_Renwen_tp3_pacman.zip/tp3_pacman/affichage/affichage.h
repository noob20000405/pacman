/**
 * \file affichage.h
 * \brief bibliotheque de affichage.c
 */
#ifndef AFFICHAGE_H
#define AFFICHAGE_H
#define P_SIZE 10
#define CLOSE printf("\033[0m"); 
#define RED printf("\033[31m"); 
#define GREEN printf("\033[36m");
#define YELLOW printf("\033[33m");
#define BLUE printf("\033[34m");

/**
 * \brief Affiche les entiers contenus dans le tableau (utile pour d´eboguer).
 * \param pl le plateau.
 * \return Rien.
 */
void afficher_brut(int** pl);

/**
 * \brief Affiche le plateau.
 * \param pl le plateau.
 * \return Rien.
 */
void afficher(int** pl);

#endif

