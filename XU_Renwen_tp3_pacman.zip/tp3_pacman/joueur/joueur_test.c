/**
 * \file joueur_test.c
 * \brief test pour joueur.c
 */
#include<stdio.h>
#include<stdlib.h>
#include"joueur.h"
#include"../plateau/plateau.h"
#include"../affichage/affichage.h"

int main(){
  int** pl=creer_plateau();

  afficher(pl);
  joueur_t *jou = placer_j(pl);
  
  afficher(pl);
  
  deplacer_j(pl,jou);//test deplacer_j et update_j.
  update_j(pl,jou);

  afficher(pl);
  return 0;
}

