/**
 * \file joueur.c
 * \brief joueur.c
 */
#include<stdio.h>
#include<stdlib.h>
#include"joueur.h"
#include"../plateau/plateau.h"

joueur_t *placer_j(int** pl){
  joueur_t *jou;
  jou = malloc(sizeof(joueur_t*));
  
  jou->i = 0;
  jou->j = 0;
  
  while(!valide(pl, jou->i, jou->j))//assurer cette coordonée est valide.
  {
    printf("Choisir votre position : (entre 1, 1 et %d, %d)\n", P_SIZE-2, P_SIZE-2);
    scanf("%d, %d",&(jou->i),&(jou->j));
  }
  
  pl[jou->i][jou->j] = 4;  //mettre le joueur dans la position.

  return jou;
}


void deplacer_j(int** pl, joueur_t *jou){
  char place;//le choix de joueur(entre 'w','a','s','d')
  
  printf("Votre deplacement (a, w, s, d) : ");
  scanf("%c", &place);
  
  if(place=='w' && valide(pl,jou->i+1,jou->j))//vers en bas.
  {
  	if(pl[jou->i+1][jou->j] == 1)
  	{
  		jou->nb_pac++;
  	}
  	
  	pl[jou->i][jou->j]=0;
    	jou->i++;
  }
  
  else if(place=='s'&& valide(pl,jou->i,(jou->j)-1))//vers à gauche.
  {
  	if(pl[jou->i][jou->j-1] == 1)
  	{
  		jou->nb_pac++;
  	}
  	
  	pl[jou->i][jou->j]=0;
	jou->j--;
  }
  
  else if(place=='a'&& valide(pl,(jou->i)-1,jou->j))//vers en haut.
  {
  	if(pl[jou->i-1][jou->j] == 1)
  	{
  		jou->nb_pac++;
  	}
  	
  	pl[jou->i][jou->j]=0;
	jou->i--;
  }
  
  else if(place=='d'&& valide(pl,jou->i,jou->j+1))//vers à droite.
  {
  	if(pl[jou->i][jou->j+1] == 1)
  	{
  		jou->nb_pac++;
  	}
  	
  	pl[jou->i][jou->j]=0;
	jou->j++;
	
  }
}


void update_j(int** pl, joueur_t *jou){
  pl[jou->i][jou->j]=4;
}
