/**
 * \file joueur.h
 * \brief bibliotheque de joueur.c
 */
#ifndef JOUEUR_H
#define JOUEUR_H

/**
 * \struct jouer
 * \typedef joueur_t
 * \brief struct d'un joueur(i, j : la position;nb_pac : nombre de points).
 */
struct joueur{
  int i;
  int j;
  int nb_pac;
};

typedef struct joueur joueur_t;

/**
 * \brief Crée le joueur en choisissant ses coordonnées sur le plateau.
 * \param pl le plateau.
 * \return Un pointeur vers une type de joueur_t. 
 */
joueur_t* placer_j(int** pl);

/**
 * \brief Déplacer le joueur.
 * \param pl le plateau.
 * \param jou le joueur.
 * \return rien
 */
void deplacer_j(int** pl, joueur_t* jou);

/**
 * \brief Modifie l’emplacement du joueur dans le plateau après qu’il se soit déplacé.
 * \param pl le plateau.
 * \param jou le joueur.
 * \return rien
 */
void update_j(int** pl, joueur_t* jou);

#endif
