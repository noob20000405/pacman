var searchData=
[
  ['deplacer_5fj',['deplacer_j',['../joueur_8c.html#a49073eacc72356aa5f16aa8171165554',1,'deplacer_j(int **pl, joueur_t *jou):&#160;joueur.c'],['../joueur_8h.html#a49073eacc72356aa5f16aa8171165554',1,'deplacer_j(int **pl, joueur_t *jou):&#160;joueur.c']]]
];
