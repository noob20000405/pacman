var searchData=
[
  ['nb_5fpac',['nb_pac',['../structjoueur.html#a9455f5029f53db0e461294d23a2e2f0c',1,'joueur']]]
];
