var searchData=
[
  ['update_5fj',['update_j',['../joueur_8c.html#a10eb559c24046b80f9fe615cc2b95f5d',1,'update_j(int **pl, joueur_t *jou):&#160;joueur.c'],['../joueur_8h.html#a10eb559c24046b80f9fe615cc2b95f5d',1,'update_j(int **pl, joueur_t *jou):&#160;joueur.c']]]
];
