var searchData=
[
  ['placer_5fj',['placer_j',['../joueur_8c.html#aeb6991291885c8b43c4d5301af5fa059',1,'placer_j(int **pl):&#160;joueur.c'],['../joueur_8h.html#aeb6991291885c8b43c4d5301af5fa059',1,'placer_j(int **pl):&#160;joueur.c']]]
];
